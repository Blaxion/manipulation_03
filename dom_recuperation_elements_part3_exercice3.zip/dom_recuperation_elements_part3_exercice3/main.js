let myObject = {
    nom: 'nicolas',
    age: 18,
}

